function q = a_interno(qUsuario)
%A_INTERNO  Convierte q de unidades del usuario (° y m) a unidades de MATLAB (rad y m).
J = articulaciones();
q = qUsuario(:)';
rot = J.tipo == "revolute";
q(rot) = deg2rad(q(rot));
end
