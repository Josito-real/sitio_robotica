function robot = robot_modelo()
%ROBOT_MODELO  Devuelve el modelo rigidBodyTree del robot asignado.
%   El modelo se carga una sola vez y se reutiliza; si se cambia el efector
%   en config_robot.m, se vuelve a cargar automáticamente.

persistent modelo archivoCargado
cfg = config_robot();
if isempty(modelo) || archivoCargado ~= cfg.urdf
    modelo = importrobot(cfg.urdf);
    modelo.DataFormat = "row";                  % q como vector fila
    archivoCargado = cfg.urdf;
end
robot = modelo;
end
