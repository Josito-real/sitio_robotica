function comparar_espacios_laser(N)
%COMPARAR_ESPACIOS_LASER  Espacio de trabajo del TCP vs. puntos que el láser
%   puede marcar en la pared (espacio de la tarea "apuntar a la pared").
%
%   comparar_espacios_laser        usa 5000 configuraciones aleatorias
%   comparar_espacios_laser(N)     usa N configuraciones

if nargin < 1, N = 5000; end
cfg   = config_robot();
robot = robot_modelo();
J     = articulaciones();
yPared = [-1.5 1.5];  zPared = [0 1.5];        % tamaño de la pared dibujada (m)

lo = J.lim(:,1)';  hi = J.lim(:,2)';
TCP = zeros(N,3);  S = nan(N,3);
for k = 1:N
    q = lo + rand(1,J.n).*(hi - lo);
    T = getTransform(robot, q, "tool0");
    P = T(1:3,4);  d = T(1:3,3);
    TCP(k,:) = P';
    if d(1) > 1e-9
        s = P + (cfg.xPared - P(1))/d(1) * d;
        if s(2) >= yPared(1) && s(2) <= yPared(2) && s(3) >= zPared(1) && s(3) <= zPared(2)
            S(k,:) = s';
        end
    end
end
S = S(~isnan(S(:,1)), :);

fprintf("\n===== ESPACIO DE TRABAJO vs. ESPACIO DE LA TAREA (láser) =====\n");
fprintf("Configuraciones aleatorias evaluadas: %d\n", N);
fprintf("El TCP nunca pasa de x = %.3f m; la pared está en x = %.2f m.\n", max(TCP(:,1)), cfg.xPared);
if isempty(S)
    fprintf("Ninguna configuración puso el punto láser sobre la pared dibujada.\n");
else
    fprintf("Aun así, %.1f%% de las configuraciones ponen el punto láser sobre la pared\n", 100*size(S,1)/N);
    fprintf("dibujada, cubriendo y en [%.2f, %.2f] m y z en [%.2f, %.2f] m.\n", ...
            min(S(:,2)), max(S(:,2)), min(S(:,3)), max(S(:,3)));
end
fprintf("==============================================================\n");

figure("Name","Espacio de trabajo vs. espacio de la tarea");
datosM = datos_modelo();
show(robot, a_interno(datosM.qRef), Frames="off"); hold on;
h1 = scatter3(TCP(:,1), TCP(:,2), TCP(:,3), 3, [0.1 0.3 0.8], "filled");
h2 = scatter3(S(:,1), S(:,2), S(:,3), 3, [0.85 0.05 0.05], "filled");
x = cfg.xPared;
fill3([x x x x], [yPared(1) yPared(2) yPared(2) yPared(1)], ...
      [zPared(1) zPared(1) zPared(2) zPared(2)], [0.8 0.8 0.8], FaceAlpha=0.2, EdgeColor=[0.3 0.3 0.3]);
legend([h1 h2], ["Posiciones alcanzables del TCP (espacio de trabajo)", ...
                 "Puntos del láser en la pared (tarea)"], Location="northoutside");
axis equal; view(-40, 20); hold off;
end
