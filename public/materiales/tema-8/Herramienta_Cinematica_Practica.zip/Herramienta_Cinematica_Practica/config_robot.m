function cfg = config_robot()
%CONFIG_ROBOT  Configuración de la tarea. Es el ÚNICO archivo de ajustes.
%
%   efector : "laser" o "pinza"  -> elige el URDF que se carga
%   xPared  : posición (m) de la pared vertical x = xPared usada con el láser
%
%   El modelo de robot viene asignado en datos_modelo.m: no lo modifique.

cfg.efector = "laser";                      % <-- "laser" o "pinza"
cfg.xPared  = 1.5;                          % pared en x = 1.5 m
cfg.zPiso   = 0;                            % plano de montaje (criterio práctico)

datos = datos_modelo();
cfg.modelo = datos.nombre;
cfg.urdf   = "robot_" + cfg.modelo + "_" + cfg.efector + ".urdf";
end
