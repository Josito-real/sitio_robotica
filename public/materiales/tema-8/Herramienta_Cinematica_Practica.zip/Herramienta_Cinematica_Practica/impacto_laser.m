function [punto, P, d] = impacto_laser(qUsuario)
%IMPACTO_LASER  Cinemática directa del láser: dónde toca el haz la pared.
%
%   [punto, P, d] = impacto_laser(q)   q en unidades del usuario (° y m)
%     punto : punto de impacto en la pared x = xPared (NaN si no la toca)
%     P     : posición del TCP (punta del láser)
%     d     : dirección del haz (eje z de tool0, vector unitario)
%
%   El haz es la recta P + t*d con t >= 0. Toca la pared cuando
%   P(1) + t*d(1) = xPared  ->  t = (xPared - P(1)) / d(1)

cfg   = config_robot();
robot = robot_modelo();
T = getTransform(robot, a_interno(qUsuario), "tool0");
P = T(1:3,4);
d = T(1:3,3);
punto = nan(3,1);
if d(1) > 1e-9                            % el haz avanza hacia la pared
    t = (cfg.xPared - P(1)) / d(1);
    if t >= 0
        punto = P + t*d;
    end
end
end
