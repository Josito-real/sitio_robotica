function q = tomar_pieza(p, giroDeg, gui)
%TOMAR_PIEZA  Pinza: tomar una pieza desde arriba con la pinza girada.
%
%   q = tomar_pieza([x y z], giro)        giro en grados
%   q = tomar_pieza([x y z], giro, gui)   además mueve la figura interactiva
%
%   Pide la pose COMPLETA de la herramienta:
%     - TCP en p (centro de agarre de la pieza)
%     - herramienta apuntando hacia abajo (eje z de tool0 = -z0)
%     - pinza girada "giro" grados alrededor de la vertical: el eje x de
%       tool0 forma ese ángulo con x0 (los dedos cierran a lo largo de y de tool0)
%   Devuelve q en unidades del usuario (° y m), o NaN si no es alcanzable.

persistent solver archivoSolver qSemilla
cfg   = config_robot();
robot = robot_modelo();
J     = articulaciones();
datos = datos_modelo();
if isempty(solver) || archivoSolver ~= cfg.urdf
    solver = inverseKinematics("RigidBodyTree", robot);
    qSemilla = a_interno(datos.qSemilla);
    archivoSolver = cfg.urdf;
end
if nargin < 3, gui = []; end
q = nan(1, J.n);
p = p(:)';

g = deg2rad(giroDeg);
Rz = [cos(g) -sin(g) 0; sin(g) cos(g) 0; 0 0 1];
Rabajo = diag([1 -1 -1]);                 % z hacia abajo, x según x0 (giro = 0)
Tdes = [Rz*Rabajo, p(:); 0 0 0 1];

[qSol, info] = solver("tool0", Tdes, ones(1,6), qSemilla);
T = getTransform(robot, qSol, "tool0");
ePos = norm(T(1:3,4) - p(:));
Rerr = T(1:3,1:3)' * Tdes(1:3,1:3);
eAng = acosd(min(1, max(-1, (trace(Rerr) - 1)/2)));

fprintf("\nTomar pieza en (%.3f, %.3f, %.3f) m con la pinza girada %.1f°\n", p, giroDeg);
if ePos > 1e-3 || eAng > 0.5
    fprintf("*** No alcanzable con esa orientación: queda a %.1f mm y %.1f° de la pose pedida.\n", 1000*ePos, eAng);
    return
end
qSemilla = qSol;
q = a_usuario(qSol);
fprintf("Solver: %s | q = %s\n", info.Status, texto_q(q));
fprintf("Error de posición: %.2e m | error de orientación: %.2e°\n", ePos, eAng);
if ~isempty(gui)
    gui.Configuration = qSol(:);
else
    figure; show(robot, qSol, Visuals="on", Frames="off"); hold on;
    plot3(p(1), p(2), p(3), "rx", MarkerSize=14, LineWidth=2);
    title(sprintf("Pieza en (%.2f, %.2f, %.2f) m, giro %.0f°", p, giroDeg)); axis equal; hold off;
end
end
