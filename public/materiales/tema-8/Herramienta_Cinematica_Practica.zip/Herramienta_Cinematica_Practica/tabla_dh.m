function DH = tabla_dh(q)
%TABLA_DH  Tabla de Denavit-Hartenberg (convención estándar) del robot asignado.
%
%   DH = tabla_dh(q) devuelve una matriz de n filas (n = grados de libertad);
%   la fila i es  [theta_i  d_i  a_i  alpha_i]
%   para la configuración q = [q1 ... qn] en unidades de MATLAB
%   (radianes para articulaciones rotacionales, metros para prismáticas).
%
%   Convención (Clase 8.1):
%   i-1_A_i = Rotz(theta_i) · Trasz(d_i) · Trasx(a_i) · Rotx(alpha_i)
%   Marco {0}: el de la base (base_link). Marco {n}: tool0 (TCP, z a lo
%   largo de la herramienta). Ver el esquema del modelo.
%
%   IMPORTANTE: para que su T coincida con la de MATLAB, su asignación de
%   marcos debe respetar tres cosas que fija el esquema:
%     1) Marco {0}: el de la base, con origen en el piso, z0 hacia arriba y
%        x0 e y0 como en el esquema.
%     2) Cada eje z(i-1) apunta en el sentido de la flecha (o del símbolo
%        de punto o cruz) de la articulación Ji en el esquema. Ese es el
%        sentido en que qi es positiva.
%     3) Último marco = tool0: origen en el TCP, z según la flecha roja y x
%        según la flecha verde.
%   Las demás decisiones del algoritmo (por ejemplo, el sentido de los x
%   intermedios) son libres: cambian los números de la tabla, pero no la T.
%
%   TODO: reemplace cada NaN por el valor que obtuvo con el algoritmo D-H.
%     - Use q(1), q(2), ... para las variables articulares.
%     - Articulación rotacional: la variable va en theta, por ejemplo
%       q(2), o q(2) + pi/2 si hace falta un desfase (offset) para
%       llevar x(i-1) a x(i) en la postura del esquema.
%     - Articulación prismática: la variable va en d, por ejemplo q(3),
%       y theta es una constante (0, pi/2, ...).
%     - Los ángulos van en radianes (por ejemplo, pi/2 para 90°).

%       theta_i        d_i            a_i       alpha_i
DH = [ NaN            NaN            NaN       NaN      ;   % i = 1
       NaN            NaN            NaN       NaN      ;   % i = 2
       NaN            NaN            NaN       NaN      ;   % i = 3
       NaN            NaN            NaN       NaN      ;   % i = 4
       NaN            NaN            NaN       NaN       ];   % i = 5
end
