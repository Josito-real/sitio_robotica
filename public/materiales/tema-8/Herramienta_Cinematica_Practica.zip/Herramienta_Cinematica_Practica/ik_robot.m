function q = ik_robot(p, d, gui)
%IK_ROBOT  Cinemática inversa numérica: posición del TCP y, opcionalmente,
%   dirección de la herramienta.
%
%   q = ik_robot([x y z])                 solo posición del TCP (m)
%   q = ik_robot([x y z], [dx dy dz])     posición + dirección de la herramienta
%                                         (eje z de tool0); [0 0 -1] = hacia abajo
%   q = ik_robot([x y z], d, gui)         además mueve la figura interactiva
%   q = ik_robot([x y z], [], gui)        solo posición, moviendo la figura
%
%   Devuelve q en unidades del usuario (° y m), o NaN si no es alcanzable.
%   Usa generalizedInverseKinematics con una restricción de posición
%   (constraintPositionTarget) y, si se da d, una de apuntado (constraintAiming).

persistent gikP gikPA archivoSolver qSemilla
cfg   = config_robot();
robot = robot_modelo();
L     = limites_robot("silencio");
J     = L.J;
datos = datos_modelo();
if isempty(gikP) || archivoSolver ~= cfg.urdf
    gikP  = generalizedInverseKinematics("RigidBodyTree", robot, "ConstraintInputs", {'position'});
    gikPA = generalizedInverseKinematics("RigidBodyTree", robot, "ConstraintInputs", {'position','aiming'});
    qSemilla = a_interno(datos.qSemilla);
    archivoSolver = cfg.urdf;
end
if nargin < 2, d = []; end
if nargin < 3, gui = []; end
tolPos = 1e-3;                            % 1 mm
tolAng = 0.5;                             % 0.5°
q = nan(1, J.n);

p = p(:)';
if numel(p) ~= 3, error("La posición debe escribirse como [x y z] en metros."); end
if ~isempty(d)
    d = d(:)' / norm(d);
    fprintf("\nObjetivo: TCP en (%.3f, %.3f, %.3f) m, herramienta hacia (%.3f, %.3f, %.3f)\n", p, d);
else
    fprintf("\nObjetivo: TCP en (%.3f, %.3f, %.3f) m, dirección libre\n", p);
end

% ---------- 1) Chequeos rápidos (condiciones necesarias) ----------
if norm(p) > L.cotaAlcance
    fprintf("*** FUERA DEL ESPACIO DE TRABAJO: el punto está a %.3f m de la base y ninguna\n", norm(p));
    fprintf("    configuración puede llegar más allá de %.3f m (suma de longitudes).\n", L.cotaAlcance);
    return
end
if p(3) < L.zPiso
    fprintf("*** FUERA DEL ESPACIO DE TRABAJO: z = %.3f m está por debajo del plano de montaje.\n", p(3));
    return
end

% ---------- 2) Cinemática inversa numérica ----------
posCon = constraintPositionTarget("tool0");
posCon.TargetPosition = p;
if isempty(d)
    [qSol, info] = gikP(qSemilla, posCon);
else
    aimCon = constraintAiming("tool0");
    aimCon.TargetPoint = p + d;           % el eje z de tool0 debe apuntar en la dirección d
    [qSol, info] = gikPA(qSemilla, posCon, aimCon);
end
[ePos, eAng] = errores(robot, qSol, p, d);
alcanzado = ePos <= tolPos && (isempty(d) || eAng <= tolAng);

% ---------- 3) Diagnóstico si no se alcanzó ----------
if ~alcanzado && ~isempty(d)
    q2 = gikP(qSemilla, posCon);          % ¿el problema es la dirección?
    e2 = errores(robot, q2, p, []);
    if e2 <= tolPos
        T2 = getTransform(robot, q2, "tool0");
        fprintf("*** La POSICIÓN es alcanzable, pero NO con esa dirección de la herramienta.\n");
        fprintf("    Lo más cerca fue un desvío de %.1f°. Una dirección posible en ese punto es\n", eAng);
        fprintf("    (%.3f, %.3f, %.3f). Pruebe otra dirección u omítala.\n", T2(1:3,3));
        return
    end
    qSol = q2;  ePos = e2;
end
if ~alcanzado
    Tsol = getTransform(robot, qSol, "tool0");
    fprintf("*** FUERA DEL ESPACIO DE TRABAJO: lo más cerca que llega el robot es\n");
    fprintf("    (%.3f, %.3f, %.3f) m, a %.1f mm del objetivo.\n", Tsol(1:3,4), 1000*ePos);
    fprintf("    Escriba limites_robot(""graficar"") para ver la zona alcanzable.\n");
    return
end

% ---------- 4) Punto alcanzable ----------
qSemilla = qSol;                          % la próxima búsqueda arranca desde aquí
Tsol = getTransform(robot, qSol, "tool0");
q = a_usuario(qSol);
fprintf("Dentro del espacio de trabajo. Solver: %s\n", info.Status);
fprintf("q = %s\n", texto_q(q));
fprintf("TCP alcanzado = (%.4f, %.4f, %.4f) m | error: %.2e m\n", Tsol(1:3,4), ePos);
fprintf("Dirección de la herramienta = (%.3f, %.3f, %.3f)\n", Tsol(1:3,3));

if ~isempty(gui)
    gui.Configuration = qSol(:);
else
    figure; show(robot, qSol, Visuals="on", Frames="off"); hold on;
    plot3(p(1), p(2), p(3), "rx", MarkerSize=14, LineWidth=2);
    title(sprintf("Objetivo (%.2f, %.2f, %.2f) m", p)); axis equal; hold off;
end
end

function [ePos, eAng] = errores(robot, q, p, d)
% Error de posición (m) y desvío de la dirección de la herramienta (°)
T = getTransform(robot, q, "tool0");
ePos = norm(T(1:3,4) - p(:));
if isempty(d)
    eAng = 0;
else
    eAng = acosd(min(1, max(-1, T(1:3,3)' * d(:))));
end
end
