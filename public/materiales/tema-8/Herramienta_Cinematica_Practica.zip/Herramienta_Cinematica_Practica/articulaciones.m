function J = articulaciones()
%ARTICULACIONES  Datos de las articulaciones móviles del robot (leídos del URDF).
%
%   J.n       número de grados de libertad
%   J.tipo    "revolute" o "prismatic" para cada articulación
%   J.lim     límites en unidades internas (rad o m), una fila por articulación
%   J.unidad  "°" o "m", unidad en que el usuario escribe cada variable
%
%   Convención de unidades para el USUARIO: ángulos en grados y
%   desplazamientos en metros. Internamente MATLAB usa radianes y metros.

robot = robot_modelo();
J.tipo = strings(0);  J.lim = zeros(0,2);
for k = 1:robot.NumBodies
    jt = robot.Bodies{k}.Joint;
    if jt.Type ~= "fixed"
        J.tipo(end+1) = string(jt.Type);
        J.lim(end+1,:) = jt.PositionLimits;
    end
end
J.n = numel(J.tipo);
J.unidad = repmat("°", 1, J.n);
J.unidad(J.tipo == "prismatic") = "m";
end
