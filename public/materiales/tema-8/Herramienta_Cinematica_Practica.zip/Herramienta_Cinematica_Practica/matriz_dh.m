function A = matriz_dh(theta, d, a, alpha)
%MATRIZ_DH  Matriz de transformación homogénea i-1_A_i de Denavit-Hartenberg.
%
%   A = matriz_dh(theta, d, a, alpha)   ángulos en radianes, distancias en m
%
%   Convención estándar (Clase 8.1):
%   A = Rotz(theta) · Trasz(d) · Trasx(a) · Rotx(alpha)

A = [ cos(theta)  -cos(alpha)*sin(theta)   sin(alpha)*sin(theta)   a*cos(theta) ;
      sin(theta)   cos(alpha)*cos(theta)  -sin(alpha)*cos(theta)   a*sin(theta) ;
      0            sin(alpha)              cos(alpha)              d            ;
      0            0                       0                       1            ];
end
