function L = limites_robot(modo)
%LIMITES_ROBOT  Límites articulares y espacio de trabajo del robot asignado.
%
%   limites_robot                 imprime los límites en la consola
%   limites_robot("graficar")     imprime y dibuja la nube de puntos alcanzables
%   L = limites_robot("silencio") solo devuelve la estructura (uso interno)
%
%   El espacio de trabajo se estima por Monte Carlo: se evalúan muchas
%   configuraciones aleatorias dentro de los límites y se registra dónde
%   queda el TCP. Es una ESTIMACIÓN: el veredicto definitivo sobre si un
%   punto es alcanzable lo da ik_robot, que verifica su solución.

if nargin < 1, modo = "imprimir"; end
persistent nube archivoNube
cfg   = config_robot();
robot = robot_modelo();
J     = articulaciones();

% ---- Nube de Monte Carlo (se calcula una vez por modelo)
if isempty(nube) || archivoNube ~= cfg.urdf
    N = 6000;  nube = zeros(N,3);
    lo = J.lim(:,1)';  hi = J.lim(:,2)';
    for k = 1:N
        q = lo + rand(1,J.n).*(hi - lo);
        T = getTransform(robot, q, "tool0");
        nube(k,:) = T(1:3,4)';
    end
    archivoNube = cfg.urdf;
end

% ---- Cota superior segura del alcance: suma de las distancias entre
%      articulaciones consecutivas en la postura cero más las carreras
%      máximas de las prismáticas (desigualdad triangular).
cotaAlcance = 0;  Tprev = eye(4);
cuerpos = string(robot.BodyNames);
for k = 1:numel(cuerpos)
    T = getTransform(robot, zeros(1,J.n), cuerpos(k));
    cotaAlcance = cotaAlcance + norm(T(1:3,4) - Tprev(1:3,4));
    Tprev = T;
end
cotaAlcance = cotaAlcance + sum(max(abs(J.lim(J.tipo=="prismatic",:)), [], 2));

L.J = J;
L.nube = nube;
L.cotaAlcance = cotaAlcance;
L.distMax = max(vecnorm(nube, 2, 2));
L.xRango = [min(nube(:,1)) max(nube(:,1))];
L.yRango = [min(nube(:,2)) max(nube(:,2))];
L.zRango = [min(nube(:,3)) max(nube(:,3))];
L.zPiso  = cfg.zPiso;

if modo == "silencio", return; end

fprintf("\n=========== LÍMITES DEL ROBOT «%s» (%d DOF) ===========\n", cfg.modelo, J.n);
fprintf("Límites articulares (del URDF):\n");
for k = 1:J.n
    if J.tipo(k) == "revolute"
        fprintf("  J%d rotacional : %8.1f°  a  %+8.1f°\n", k, rad2deg(J.lim(k,:)));
    else
        fprintf("  J%d prismática : %8.3f m a  %8.3f m\n", k, J.lim(k,:));
    end
end
fprintf("\nEspacio de trabajo del TCP (estimado con %d configuraciones aleatorias):\n", size(nube,1));
fprintf("  x entre %6.3f y %6.3f m\n", L.xRango);
fprintf("  y entre %6.3f y %6.3f m\n", L.yRango);
fprintf("  z entre %6.3f y %6.3f m\n", L.zRango);
fprintf("  Distancia máxima a la base observada: %.3f m\n", L.distMax);
fprintf("  Cota superior teórica del alcance   : %.3f m (suma de longitudes)\n", L.cotaAlcance);
fprintf("  Límite práctico: z >= %.3f m (plano de montaje)\n", L.zPiso);
fprintf("=========================================================\n");

if modo == "graficar"
    figure("Name","Espacio de trabajo");
    datosM = datos_modelo();
    show(robot, a_interno(datosM.qRef), Frames="off"); hold on;
    scatter3(nube(:,1), nube(:,2), nube(:,3), 4, nube(:,3), "filled");
    colorbar; axis equal; hold off;
    title(sprintf("Espacio de trabajo del TCP (%d configuraciones aleatorias)", size(nube,1)));
end
end
