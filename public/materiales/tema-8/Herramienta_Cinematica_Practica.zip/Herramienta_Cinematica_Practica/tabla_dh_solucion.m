function DH = tabla_dh_solucion(q)
%TABLA_DH_SOLUCION  Solución de referencia de la tabla de Denavit-Hartenberg (convención estándar) del robot asignado.
%
%   Úsela solo para comparar DESPUÉS de intentar su propia tabla en tabla_dh.m.
%   Otra tabla distinta también puede ser correcta: el criterio es la
%   sección 3b de tarea_cinematica.m, no la igualdad con esta solución.
%
%   DH = tabla_dh_solucion(q) devuelve una matriz de n filas (n = grados de libertad);
%   la fila i es  [theta_i  d_i  a_i  alpha_i]
%   para la configuración q = [q1 ... qn] en unidades de MATLAB
%   (radianes para articulaciones rotacionales, metros para prismáticas).
%
%   Convención (Clase 8.1):
%   i-1_A_i = Rotz(theta_i) · Trasz(d_i) · Trasx(a_i) · Rotx(alpha_i)
%   Marco {0}: el de la base (base_link). Marco {n}: tool0 (TCP, z a lo
%   largo de la herramienta). Ver el esquema del modelo.

%       theta_i        d_i            a_i       alpha_i
DH = [ q(1)           0.1            0         0        ;   % i = 1
       0              q(2)           0.3       0        ;   % i = 2
       q(3)           0              0.25      pi/2     ;   % i = 3
       q(4) + pi/2    0              0         pi/2     ;   % i = 4
       q(5)           0.1            0         0         ];   % i = 5
end
