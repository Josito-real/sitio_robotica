function q = apuntar_laser(objetivo, qSemillaUsuario, dibujar)
%APUNTAR_LASER  Busca una configuración con la que el haz pase por un punto.
%
%   q = apuntar_laser([x y z])                  semilla por defecto
%   q = apuntar_laser([x y z], qSemilla)        semilla en unidades del usuario
%   q = apuntar_laser([x y z], qSemilla, false) sin dibujar
%
%   La tarea "poner el punto del láser en el objetivo" solo exige que el eje
%   z de tool0 apunte al objetivo (restricción constraintAiming); la posición
%   del TCP queda libre. Por eso suele haber infinitas soluciones: distintas
%   semillas llevan a distintas configuraciones que marcan el mismo punto.
%   Devuelve q en unidades del usuario (° y m), o NaN si no lo logra.

persistent gikA archivoSolver
cfg   = config_robot();
robot = robot_modelo();
J     = articulaciones();
datos = datos_modelo();
if isempty(gikA) || archivoSolver ~= cfg.urdf
    gikA = generalizedInverseKinematics("RigidBodyTree", robot, "ConstraintInputs", {'aiming'});
    archivoSolver = cfg.urdf;
end
if nargin < 2 || isempty(qSemillaUsuario), qSemillaUsuario = datos.qSemilla; end
if nargin < 3, dibujar = true; end
objetivo = objetivo(:)';
q = nan(1, J.n);

aimCon = constraintAiming("tool0");
aimCon.TargetPoint = objetivo;
[qSol, info] = gikA(a_interno(qSemillaUsuario), aimCon);

% Verificación con cinemática directa: distancia del objetivo a la recta del haz
T = getTransform(robot, qSol, "tool0");
P = T(1:3,4);  d = T(1:3,3);
v = objetivo' - P;
distHaz = norm(cross(v, d));
delante = v' * d > 0;

fprintf("\nApuntar el láser a (%.3f, %.3f, %.3f) m desde la semilla %s\n", objetivo, texto_q(qSemillaUsuario));
if distHaz > 1e-3 || ~delante
    fprintf("*** No se logró: el haz pasa a %.1f mm del objetivo. Pruebe otra semilla.\n", 1000*distHaz);
    return
end
q = a_usuario(qSol);
fprintf("Solver: %s | q = %s\n", info.Status, texto_q(q));
fprintf("TCP = (%.3f, %.3f, %.3f) m | distancia del objetivo al haz = %.1e m\n", P, distHaz);

if dibujar
    figure;
    show(robot, qSol, Visuals="on", Frames="off"); hold on;
    plot3([P(1) objetivo(1)], [P(2) objetivo(2)], [P(3) objetivo(3)], "r-", LineWidth=2);
    plot3(objetivo(1), objetivo(2), objetivo(3), "ro", MarkerSize=10, MarkerFaceColor="r");
    x = cfg.xPared;  y = [-1.5 1.5];  z = [0 1.5];
    fill3([x x x x], [y(1) y(2) y(2) y(1)], [z(1) z(1) z(2) z(2)], [0.8 0.8 0.8], ...
          FaceAlpha=0.25, EdgeColor=[0.3 0.3 0.3]);
    axis equal; hold off; view(-35, 20);
    title("q = " + texto_q(q));
end
end
