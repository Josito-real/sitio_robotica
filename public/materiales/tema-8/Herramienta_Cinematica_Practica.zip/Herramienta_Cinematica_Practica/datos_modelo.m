function datos = datos_modelo()
%DATOS_MODELO  Datos del modelo asignado. NO MODIFICAR.
%   Unidades del usuario: grados (rotacionales) y metros (prismáticas, posiciones).

datos.nombre = "practica";
datos.titulo = "Columna elevadora: R-P-R + muñeca de cabeceo y giro";

% Postura del esquema y de las figuras (rotacionales en 0; prismáticas en un
% valor de su rango, porque en q = 0 quedan fuera de él)
datos.qRef = [0  0.3  0  0  0];

% Configuración de partida para los solvers de cinemática inversa
datos.qSemilla = [0  0.3  30  -30  0];

% Configuraciones de prueba para la cinemática directa (una por fila)
datos.qPrueba = [ 0  0.3  0  0  0 ;
                   30  0.4  45  -45  60 ;
                   -90  0.2  -60  30  -90 ;
                   120  0.45  100  -90  30 ];

% Objetivos de cinemática inversa: [x y z dx dy dz]
% (dx dy dz) = dirección deseada de la herramienta; NaN = dirección libre
datos.objetivosIK = [ 0.4  0.2  0.4  NaN  NaN  NaN ;
                   0.4  0.15  0.2  0  0  -1 ;
                   0.65  0  0.45  1  0  0 ;
                   0.4  0.15  0.4  0  1  0 ;
                   1.4  0  0.3  NaN  NaN  NaN ;
                   0.3  0  -0.02  NaN  NaN  NaN ];

% Láser: configuración para la cinemática directa, punto objetivo en la
% pared y semillas para mostrar la redundancia (una por fila)
datos.qLaser = [20  0.4  -20  10  0];
datos.objetivoLaser = [1.5  0.3  0.6];
datos.semillasLaser = [ 10  0.4  0  0  0 ;
                   30  0.3  -40  20  0 ;
                   -10  0.5  20  -10  0 ;
                   40  0.45  -60  5  0 ];

% Pinza: posición de la pieza (m) y giros de la pinza a probar (°)
datos.pieza = [0.4  0.15  0.2];
datos.girosPieza = [30  -60];
end
