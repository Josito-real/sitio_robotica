function [T, A] = fk_dh(q)
%FK_DH  Cinemática directa por el producto de matrices de Denavit-Hartenberg.
%
%   [T, A] = fk_dh(q)   q en unidades de MATLAB (rad para rotacionales, m para prismáticas)
%     T : pose del TCP respecto a la base,  T = 0_A_1 · 1_A_2 · ... · n-1_A_n
%     A : celda con las matrices individuales, A{i} = i-1_A_i

DH = tabla_dh(q);
n = size(DH, 1);
A = cell(1, n);
T = eye(4);
for i = 1:n
    A{i} = matriz_dh(DH(i,1), DH(i,2), DH(i,3), DH(i,4));
    T = T * A{i};
end
end
