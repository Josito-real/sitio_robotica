%% TAREA - Cinemática directa e inversa de un robot manipulador
% Robótica Industrial FPTEN27 - UNIMET
%
% Requiere: MATLAB R2021a o posterior con Robotics System Toolbox.
%           Symbolic Math Toolbox es opcional (sección 3d).
%
% Ejecute el script SECCIÓN POR SECCIÓN (Ctrl+Enter) y lea la consola.
% Unidades para el usuario: grados (rotacionales) y metros (prismáticas).
%
% Archivo que usted debe completar:  tabla_dh.m (tabla de Denavit-Hartenberg)
% Ya resueltos (léalos):              matriz_dh.m (fila -> matriz A_i)
%                                     fk_dh.m (producto de las matrices)
% Archivo de ajustes:                 config_robot.m (efector y pared)
clear; clc; close all;
delete(timerfindall);                         % elimina monitores de ejecuciones previas
cfg   = config_robot();
datos = datos_modelo();
robot = robot_modelo();
J     = articulaciones();
fprintf("Modelo «%s»: %s\nArchivo: %s (efector: %s)\n", cfg.modelo, datos.titulo, cfg.urdf, cfg.efector);

%% 1. Modelo del robot y esquema
showdetails(robot)
figure("Name","Esquema del modelo");
imshow("esquema_" + cfg.modelo + ".png");
figure("Name","Postura del esquema");
show(robot, a_interno(datos.qRef), Visuals="on", Frames="on");
title("Postura del esquema: q = " + texto_q(datos.qRef)); axis equal;

%% 2. Límites del robot y espacio de trabajo
L = limites_robot("graficar");

%% 3a. Cinemática directa: producto de matrices DH vs. MATLAB
T0 = fk_dh(zeros(1,J.n));
if any(isnan(T0(:)))
    error("Complete la tabla DH en tabla_dh.m antes de ejecutar esta sección.");
end
for k = 1:size(datos.qPrueba,1)
    qU = datos.qPrueba(k,:);
    q  = a_interno(qU);
    T_dh = fk_dh(q);                           % su producto de matrices
    T_ml = getTransform(robot, q, "tool0");    % MATLAB, a partir del URDF
    fprintf("\n---------- q = %s ----------\n", texto_q(qU));
    disp("T por producto de matrices DH:");  disp(round(T_dh, 4));
    disp("T de MATLAB (getTransform):");     disp(round(T_ml, 4));
    fprintf("Diferencia máxima entre ambas: %.2e\n", max(abs(T_dh - T_ml), [], "all"));
end

%% 3b. Prueba masiva: 1000 configuraciones aleatorias dentro de los límites
lo = J.lim(:,1)';  hi = J.lim(:,2)';
errMax = 0;
for k = 1:1000
    q = lo + rand(1,J.n).*(hi - lo);
    errMax = max(errMax, max(abs(fk_dh(q) - getTransform(robot, q, "tool0")), [], "all"));
end
fprintf("\nDiferencia máxima en 1000 configuraciones aleatorias: %.2e\n", errMax);
if errMax < 1e-10
    disp("-> Su tabla DH reproduce el modelo del robot (la diferencia es solo redondeo numérico).");
else
    disp("-> Hay diferencias: revise la tabla DH y la matriz de transformación.");
end

%% 3c. Matrices individuales i-1_A_i para una configuración
qU = datos.qPrueba(2,:);
[T, A] = fk_dh(a_interno(qU));
fprintf("\nMatrices de transformación para q = %s:\n", texto_q(qU));
for i = 1:J.n
    fprintf("\n%d_A_%d =\n", i-1, i);  disp(round(A{i}, 4));
end
fprintf("\nT = producto de las %d matrices =\n", J.n);  disp(round(T, 4));

%% 3d. (Opcional) Cinemática directa simbólica
if license("test", "Symbolic_Toolbox")
    qs = sym("q", [1 J.n], "real");
    Tsym = simplify(fk_dh(qs));
    disp("Posición del TCP en función de las variables articulares:");  disp(Tsym(1:3,4));
    disp("Orientación del TCP (matriz de rotación):");                  disp(Tsym(1:3,1:3));
else
    disp("Symbolic Math Toolbox no disponible: se omite esta sección.");
end

%% 4. Cinemática inversa y verificación con SU cinemática directa
for k = 1:size(datos.objetivosIK,1)
    p = datos.objetivosIK(k,1:3);
    d = datos.objetivosIK(k,4:6);
    if any(isnan(d)), d = []; end
    qk = ik_robot(p, d);
    if ~any(isnan(qk))
        Tk = fk_dh(a_interno(qk));
        fprintf("  Verificación con fk_dh: TCP = (%.4f, %.4f, %.4f) m | error = %.2e m\n", ...
                Tk(1:3,4), norm(Tk(1:3,4) - p(:)));
    end
end

%% 5a. LÁSER - Cinemática directa: ¿dónde cae el punto en la pared?
if cfg.efector == "laser"
    [punto, P, d] = impacto_laser(datos.qLaser);
    fprintf("\nq = %s\n", texto_q(datos.qLaser));
    fprintf("  TCP (punta del láser) = (%.3f, %.3f, %.3f) m\n", P);
    fprintf("  Dirección del haz     = (%.3f, %.3f, %.3f)\n", d);
    fprintf("  Punto en la pared     = (%.3f, %.3f, %.3f) m\n", punto);
else
    disp("Sección para el láser: cambie cfg.efector a ""laser"" en config_robot.m");
end

%% 5b. LÁSER - Redundancia: varias configuraciones, el mismo punto en la pared
if cfg.efector == "laser"
    for k = 1:size(datos.semillasLaser,1)
        apuntar_laser(datos.objetivoLaser, datos.semillasLaser(k,:));
    end
else
    disp("Sección para el láser: cambie cfg.efector a ""laser"" en config_robot.m");
end

%% 5c. LÁSER - Espacio de trabajo vs. espacio de la tarea
if cfg.efector == "laser"
    comparar_espacios_laser(5000);
else
    disp("Sección para el láser: cambie cfg.efector a ""laser"" en config_robot.m");
end

%% 6. PINZA - Tomar una pieza desde arriba con distintos giros de la pinza
if cfg.efector == "pinza"
    for g = datos.girosPieza
        tomar_pieza(datos.pieza, g);
    end
else
    disp("Sección para la pinza: cambie cfg.efector a ""pinza"" en config_robot.m");
end

%% 7. (Opcional) Mover el robot con el ratón y ver las variables en la consola
% La consola queda libre: puede escribir, por ejemplo,
%   ik_robot([0.40 0.10 0.30], [], gui)
% para que el robot de la figura vaya a la solución.
% Para detener el monitoreo:  stop(tmr); delete(tmr)
gui = interactiveRigidBodyTree(robot, MarkerBodyName="tool0");
tmr = monitor_angulos(gui);
