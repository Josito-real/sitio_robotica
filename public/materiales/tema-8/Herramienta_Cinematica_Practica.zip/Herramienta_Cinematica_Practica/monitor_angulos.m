function tmr = monitor_angulos(gui)
%MONITOR_ANGULOS  Imprime en la consola las variables articulares cuando cambian.
%
%   gui = interactiveRigidBodyTree(robot_modelo(), MarkerBodyName="tool0");
%   tmr = monitor_angulos(gui);
%   ... mueva el robot con el ratón; la consola queda libre ...
%   stop(tmr); delete(tmr)          % para detener el monitoreo

robot = robot_modelo();
J = articulaciones();
tmr = timer('ExecutionMode','fixedRate', 'Period',0.2, 'BusyMode','drop', ...
            'UserData', inf(1,J.n), ...
            'TimerFcn', @(t,~) imprimirSiCambia(t, gui, robot));
start(tmr);
disp("Monitoreo activo. Para detenerlo: stop(tmr); delete(tmr)");
end

function imprimirSiCambia(t, gui, robot)
try
    q = gui.Configuration(:)';           % sirve si viene como fila o columna
catch
    stop(t); delete(t);
    disp("Figura cerrada: monitoreo detenido.");
    return
end
if any(abs(q - t.UserData) > 1e-3)        % ~0.06° o 1 mm
    T = getTransform(robot, q, "tool0");
    fprintf("q = %s | TCP = (%.3f, %.3f, %.3f) m | herramienta hacia (%.2f, %.2f, %.2f)\n", ...
            texto_q(a_usuario(q)), T(1:3,4), T(1:3,3));
    t.UserData = q;
end
end
