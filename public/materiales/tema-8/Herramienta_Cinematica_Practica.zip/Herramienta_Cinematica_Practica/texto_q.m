function s = texto_q(qUsuario)
%TEXTO_Q  Texto con la configuración, cada variable con su unidad.
J = articulaciones();
partes = strings(1, J.n);
for k = 1:J.n
    if J.tipo(k) == "revolute"
        partes(k) = sprintf("%.2f°", qUsuario(k));
    else
        partes(k) = sprintf("%.4f m", qUsuario(k));
    end
end
s = "[" + strjoin(partes, "  ") + "]";
end
