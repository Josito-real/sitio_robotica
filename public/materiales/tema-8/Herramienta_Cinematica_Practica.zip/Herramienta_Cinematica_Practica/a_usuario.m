function q = a_usuario(qInterno)
%A_USUARIO  Convierte q de unidades de MATLAB (rad y m) a unidades del usuario (° y m).
J = articulaciones();
q = qInterno(:)';
rot = J.tipo == "revolute";
q(rot) = rad2deg(q(rot));
end
